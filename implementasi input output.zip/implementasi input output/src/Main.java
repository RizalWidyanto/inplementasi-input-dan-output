import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner r = new Scanner(System.in);
        penjual_1 s = new penjual_2();
        penjual_2= new Pembeli();
        //counter_hp c = new conter();
        Pilihcount c = new Pilihcoun();
        bayar b = new bayar();
        struk q = new struk();

        System.out.println("Masukkan Nama Pembeli : ");
        String nama = r.nextLine();
        System.out.println("Masukkan no telp pembeli : ");
        int telp = r.nextInt();
        p.output(nama, telp);

        System.out.println("Masukkaan tanggal beli : ");
        int tglsewa = r.nextInt();
        s.output(tglbeli);

        System.out.println("Pilihan Lapangan : ");
        System.out.println("1. counter_1\n2.counter_2");
        System.out.println("Masukkan pilihan anda : ");
        int inp= r.nextInt();
        i.piill(inp);

        System.out.println("Masukkan uang pembayaran");
        int uang = r.nextInt();
        System.out.println("jenis hp yang di bayar:\n1. counter\n2. counter_1");
        int pem = r.nextInt();
        b.penyewa(pem);

        q.pembeli(inp);
        q.piill(inp);
        q.strukk(nama,telp,tglsewa);


    }
}