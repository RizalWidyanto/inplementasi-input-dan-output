import java.util.Scanner;

public class counter_hp{
    protected String jenlap;
    protected int nolap;

    public String getJenlap() {
        return jenlap;
    }

    public void setJenlap(String jenlap) {
        this.jenlap = jenlap;
    }

    public int getNocon() {
        return nolap;
    }
    public void setNolap(int nolap) {
        this.nolap = nolap;
    }
    public void output(){
        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan Nama Pembeli : ");
        setNolap(input.nextInt());
        System.out.println("Masukkan no telp pembeli : ");
        setJenlap(input.next());
        System.out.println("Nama Pembeli : "+this.nolap);
        System.out.println("No telp pembeli : "+this.jenlap);
    }
}
