import java.util.Scanner;

public class pilihcon extends counter_hp{
    Scanner  keyboard = new Scanner(System.in);

    String counter;

    @Override
    public void piill(int inp) {
        switch (inp)
        {
            case 1:

                System.out.println("counter_1");
                System.out.println("harga tetap");
                break;
            case 2:
                System.out.println("counter_2");
                System.out.println("harga tetap");
                break;
            default:
                System.out.println("ready");
                break;
        }
    }
}
