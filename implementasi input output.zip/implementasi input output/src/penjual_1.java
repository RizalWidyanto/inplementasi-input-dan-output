abstract class penjual_1{
    public abstract void piill(int inp);
}
