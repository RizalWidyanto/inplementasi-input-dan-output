public class penjual_2 {
}
public class pen_2 extends penjual_2{
    @Override
    public int getNocoun() {
        return super.();
    }
    @Override
    public String getNocoun() {
        return super.();
    }
}
