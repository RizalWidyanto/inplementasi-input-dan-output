public class Petugas {
    protected String nampet;
    protected int idpet;

    public String getNampet() {
        return nampet;
    }

    public void setNampet(String nampet) {
        this.nampet = nampet;
    }

    public int getIdpet() {
        return idpet;
    }

    public void setIdpet(int idpet) {
        this.idpet = idpet;
    }
}
