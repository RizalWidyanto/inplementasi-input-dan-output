import java.util.Scanner;

public class penjualan_hp {
    private int tgljual; 

    public int getTgljual() {
        return tgljual;
    }

    public void setTgljual(int tglsewa) {
        this.tgljual = tglsewa;
    }

    public void output(int tgljual){
        System.out.println("Masukkan tanggal jual : "+tgljual);
    }

}
